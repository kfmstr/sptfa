<#
    Check-Setup.ps1

    Compares an SPT install against the mod list in this pack and says what is
    missing. Reads only. It installs nothing and downloads nothing - get the
    mods themselves from forge.sp-tarkov.com.

    Usage, from the folder this file is in:

        powershell -ExecutionPolicy Bypass -File .\Check-Setup.ps1 -SptPath "C:\SPT"

    Add -InstallConfigs to also copy this pack's tuned configs into
    BepInEx\config, backing up anything it would overwrite.
#>

param(
    [Parameter(Mandatory = $true)][string]$SptPath,
    [switch]$InstallConfigs
)

$ErrorActionPreference = 'Stop'

# name shown -> a distinctive fragment of the file or folder name to look for
$Plugins = [ordered]@{
    'BepInEx Configuration Manager'   = 'ConfigurationManager'
    'Amands''s Graphics'              = 'AmandsGraphics'
    'Amands Sense'                    = 'AmandsSense'
    "Borkel's Realistic NVGs"         = 'BorkelRNVG'
    'NVG Sight Dimmer'                = 'NVGSightDimmer'
    'BrighterInteriors'               = 'BrighterInteriors'
    'SmajlecLights'                   = 'SmajlecLights'
    'BrightLasers'                    = 'brightlasers'
    'SAIN'                            = 'SAIN'
    'BigBrain'                        = 'BigBrain'
    'Waypoints'                       = 'Waypoints'
    'MoreBots'                        = 'MoreBots'
    'BlackDiv'                        = 'BlackDiv'
    'RUAFComeHome'                    = 'RUAFComeHome'
    'UNTARGH'                         = 'UNTARGH'
    'SearchOpenContainers'            = 'SearchOpenContainers'
    'HandsAreNotBusy'                 = 'HandsAreNotBusy'
    'IncreaseLookDirection'           = 'IncreaseLookDirection'
    'Tarkin Ladders'                  = 'ladders'
    'WTT ClientCommonLib'             = 'WTT-ClientCommonLib'
    'WTT Armory'                      = 'WTT-Armory'
    'WTT ContentBackport'             = 'WTT-ContentBackport'
    'WTT HeadVoiceSelector'           = 'WTT-HeadVoice'
    'SPT Free Aim'                    = 'SPTFreeAim'
}

$ServerMods = @(
    'acidphantasm-brightlasers', 'acidphantasm-progressivebotsystem', 'BlackDivServer',
    'BotCallsigns', 'bushtail-CantedAiming', 'MoreBotsServer', 'RUAFComeHomeServer',
    'Solarint-SAIN-ServerMod', 'TwitchPlayers', 'untargh-server', 'WTT-Armory',
    'WTT-HeadVoiceSelector', 'WTT-ServerCommonLib'
)

function Say($text, $colour) { Write-Host $text -ForegroundColor $colour }

$pluginDir = Join-Path $SptPath 'BepInEx\plugins'
$configDir = Join-Path $SptPath 'BepInEx\config'
$modDir    = Join-Path $SptPath 'user\mods'

if (-not (Test-Path $pluginDir)) {
    Say "No BepInEx\plugins under '$SptPath'. Is that the SPT folder, and has SPT been launched once?" 'Red'
    exit 1
}

# One flat list of every plugin file and folder name, so a mod that ships as a
# folder and one that ships as a loose DLL both match the same way.
$have = @(Get-ChildItem -Path $pluginDir -Recurse -Force |
          Select-Object -ExpandProperty Name)

Say "`n=== Client plugins ===" 'Cyan'
$missing = @()
foreach ($name in $Plugins.Keys) {
    $needle = $Plugins[$name]
    $found  = $have | Where-Object { $_ -like "*$needle*" } | Select-Object -First 1
    if ($found) { Say ("  ok       {0}" -f $name) 'Green' }
    else        { Say ("  MISSING  {0}" -f $name) 'Yellow'; $missing += $name }
}

Say "`n=== Server mods ===" 'Cyan'
if (-not (Test-Path $modDir)) {
    Say "  user\mods does not exist yet. Start the SPT server once." 'Yellow'
} else {
    $haveMods = @(Get-ChildItem -Path $modDir -Directory -Force | Select-Object -ExpandProperty Name)
    foreach ($m in $ServerMods) {
        if ($haveMods -contains $m) { Say ("  ok       {0}" -f $m) 'Green' }
        else { Say ("  MISSING  {0}" -f $m) 'Yellow'; $missing += "$m (server)" }
    }
}

Say "`n=== SPT version ===" 'Cyan'
$core = Join-Path $SptPath 'SPT_Data\Server\configs\core.json'
# Wrapped, because $ErrorActionPreference is Stop and core.json is not always
# strict JSON. A version check must never be the reason the whole check dies.
try {
    if (Test-Path $core) {
        $v = (Get-Content $core -Raw | ConvertFrom-Json).sptVersion
        if ($v -like '4.1.*') { Say "  ok       SPT $v" 'Green' }
        else { Say "  WARNING  SPT $v - this setup was built on 4.1.5" 'Yellow' }
    } else {
        Say "  could not find SPT_Data\Server\configs\core.json" 'Yellow'
    }
} catch {
    Say "  could not read the SPT version - carrying on" 'Yellow'
}

if ($InstallConfigs) {
    Say "`n=== Configs ===" 'Cyan'
    $src = Join-Path (Split-Path $PSScriptRoot -Parent) 'configs'
    if (-not (Test-Path $configDir)) { New-Item -ItemType Directory -Path $configDir | Out-Null }

    $stamp  = Get-Date -Format 'yyyyMMdd-HHmmss'
    $backup = Join-Path $configDir "backup-$stamp"

    foreach ($f in Get-ChildItem -Path $src -Filter *.cfg) {
        $dest = Join-Path $configDir $f.Name
        if (Test-Path $dest) {
            if (-not (Test-Path $backup)) { New-Item -ItemType Directory -Path $backup | Out-Null }
            Copy-Item $dest (Join-Path $backup $f.Name) -Force
        }
        Copy-Item $f.FullName $dest -Force
        Say ("  copied   {0}" -f $f.Name) 'Green'
    }
    if (Test-Path $backup) { Say "  your previous configs are in $backup" 'Cyan' }
}

Say "" 'White'
if ($missing.Count -eq 0) {
    Say "Everything on the list is present." 'Green'
} else {
    Say ("{0} missing. Get them from forge.sp-tarkov.com, matching SPT 4.1.5:" -f $missing.Count) 'Yellow'
    foreach ($m in $missing) { Say "    $m" 'Yellow' }
}
Say "A MISSING line is only a difference from my setup. Nothing here is required by SPT Free Aim." 'DarkGray'
