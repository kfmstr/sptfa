# My SPT setup, for friends

SPT 4.1.5. This gets you to the same game I am playing.

## What is in here

```
MODLIST.md              every mod, its version, and the order to install in
configs/                my tuning for those mods, ready to drop in
tools/Check-Setup.ps1   tells you what you are missing before you launch
```

## What is NOT in here, and why

The mods themselves. I did not bundle the DLLs.

The Forge's content guidelines are explicit about it: *"Submission of existing
user-contributed content without obtaining permission from the original authors
is strictly prohibited"*, and attribution is not a substitute for permission. Of
the forty-odd mods in this setup exactly one ships a licence that would allow me
to pass it on. So the mods come from their authors and the tuning comes from me.

That is also better for you. Downloading from the Forge means you get the right
build for your SPT version, you get updates, and the author can help you when
something breaks.

## How to use it

1. Install SPT 4.1.5 and launch it once, clean, to confirm it works.
2. Work through `MODLIST.md`. The install order there matters, particularly the
   library mods.
3. Check yourself against my setup:

   ```
   powershell -ExecutionPolicy Bypass -File .\tools\Check-Setup.ps1 -SptPath "C:\SPT"
   ```

4. When the list is clean, copy my tuning in:

   ```
   powershell -ExecutionPolicy Bypass -File .\tools\Check-Setup.ps1 -SptPath "C:\SPT" -InstallConfigs
   ```

   It backs up anything it overwrites into `BepInEx\config\backup-<timestamp>\`.

5. Start the **server**, wait for it to finish loading, then the client.

The script only reads, except for the config copy in step 4, and it never
downloads anything.

## The configs

`configs/com.Amanda.Graphics.cfg` is the one that matters most. It is most of
what the game looks like on my machine. `com.borkel.nvgmasks.cfg` is the night
vision tuning and is large because it is per-device.

The rest are small and mostly reasonable defaults with a few things moved.

`kfmstr.interiorlights.cfg` belongs to a mod of mine that is not released. The
config is harmless without it. Ask me for the DLL.

`kfmstr.sptfreeaim.cfg` is SPT Free Aim, which ships in its own zip along with
the same file.

## SPT Free Aim

That one is mine and I can hand it over freely. It is in `SPTFreeAim-0.1.0.zip`,
with its own README. The mouse points the gun, the body follows a moment later.
Drop one DLL in `BepInEx/plugins` and press F9 in a raid.
