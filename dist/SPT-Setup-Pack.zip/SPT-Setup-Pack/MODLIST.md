# The setup

SPT **4.1.5**, BepInEx 5.4.23.5, Unity 2022.3.43. 30 client plugins, 8 preloader
patchers, 13 server mods.

Everything here comes from **the Forge**, `forge.sp-tarkov.com`. Search the mod
name, take the build that matches SPT 4.1.5, and take both halves when a mod has
a client and a server part.

The `configs/` folder in this pack holds my tuning for most of these. Copy them
in after the mods are installed and you land on my setup rather than on defaults.
`tools/Check-Setup.ps1` tells you what is missing before you launch.

---

## Client plugins → `BepInEx/plugins`

### Visuals and optics

| Mod | Version | What it does here |
|---|---|---|
| Amands's Graphics | 1.8.0 | Post-processing. Config included, and it is most of the look |
| Borkel's Realistic NVGs | 3.0.2 | NVG masks and tubes. Big config, included |
| NVG Sight Dimmer | 2.1.0 | Stops sights blowing out under NVGs |
| SevenBoldPencil BrighterInteriors | 1.1.1 | Interior light levels |
| SmajlecLights | 1.3.0 | Light sources |
| acidphantasm BrightLasers | 3.0.0 | Laser visibility. MIT licensed |
| **SPT Free Aim** | **0.1.0** | Mine. Separate zip |

### Bots and AI

| Mod | Version | Notes |
|---|---|---|
| SAIN | 4.5.1 | The AI overhaul. Needs BigBrain and Waypoints first |
| DrakiaXYZ BigBrain | 1.5.0 | SAIN dependency, install before SAIN |
| DrakiaXYZ Waypoints | 1.9.0 | SAIN dependency, install before SAIN |
| MoreBotsAPI | 2.1.1 | Bot framework, install before MoreBots content |
| BlackDiv | 1.3.1 | Bot types |
| RUAFComeHome | 1.2.1 | Bot faction |
| TacticalToaster UNTARGH | 3.2.1 | Bot faction |

### Quality of life

| Mod | Version | Notes |
|---|---|---|
| DrakiaXYZ Sense (AmandsSense) | 3.1.0 | Loot and corpse highlighting |
| DrakiaXYZ SearchOpenContainers | 1.5.0 | |
| HandsAreNotBusy | 1.7.1 | |
| IncreaseLookDirection | 1.3.0 | Wider head turn. Pairs well with free aim |
| Tarkin Ladders | 1.0.4 | |
| BepInEx Configuration Manager | 18.4 | The F12 settings menu. Install this first |
| UnityExplorer | 4.9.0 | Developer tool. Skip it unless you are debugging |

### Content

| Mod | Version | Notes |
|---|---|---|
| WTT ClientCommonLib | 3.0.6 | **Install before any other WTT mod** |
| WTT Armory | 2.0.5 | |
| WTT ContentBackportClient | 2.0.1 | |
| WTT HeadVoiceSelector Core | 1.0.8 | |

### Not public

**Tarkov Interior Lights 0.4.0** is my own local build and is not on the Forge.
Its config is in `configs/kfmstr.interiorlights.cfg` but the DLL is not here.
Ask me for it.

### Ships with SPT

`SPT.Core`, `SPT.Custom`, `SPT.Debugging`, `SPT.Singleplayer`, all 4.1.5, plus
`spt-prepatch`. These arrive with SPT. Do not copy them from anywhere.

---

## Server mods → `user/mods`

acidphantasm-brightlasers, acidphantasm-progressivebotsystem, BlackDivServer,
BotCallsigns, bushtail-CantedAiming, MoreBotsServer, RUAFComeHomeServer,
Solarint-SAIN-ServerMod, TwitchPlayers, untargh-server, WTT-Armory,
WTT-HeadVoiceSelector, WTT-ServerCommonLib.

Nearly all of these are the server half of a client plugin above. Install the
pair together, never one half on its own.

`bushtail-CantedAiming` and `TwitchPlayers` and
`acidphantasm-progressivebotsystem` have no client half.

---

## Install order

1. Clean SPT 4.1.5. Launch it once, plain, and confirm it works.
2. BepInEx Configuration Manager.
3. Libraries first: WTT-ServerCommonLib and WTT-ClientCommonLib, MoreBotsAPI,
   BigBrain, Waypoints.
4. Everything else, client and server halves together.
5. SAIN last of the AI mods.
6. Copy `configs/*.cfg` into `BepInEx/config/`.
7. Start the **server** and let it finish loading before starting the client.
8. SPT Free Aim whenever you like. It depends on nothing.

Run `tools/Check-Setup.ps1` before step 7 and it will list anything missing.

## Two things that bite

**Amands Graphics owns the post-processing.** If scope or lighting effects look
wrong, check its settings before blaming anything else. It sets Tarkov's own
bloom to zero and renders its own, which is why a lot of lighting mods appear to
do nothing next to it.

**Do not put a mod hotkey on a number key.** Tarkov uses `Alpha1` and friends for
weapon slots, so a mod hotkey there fires every time you draw a weapon. This cost
me three evenings.
